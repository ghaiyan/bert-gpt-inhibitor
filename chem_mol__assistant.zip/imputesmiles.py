
import pandas as pd
from rdkit import Chem
from rdkit.Chem import rdMolDescriptors
from tqdm import tqdm

# 启用 tqdm 显示进度条
tqdm.pandas()

# 读取两个 CSV 文件
df_with_iupac = pd.read_csv('/home/ubuntu/chem_mol_assistant/Dataset/Inhibitor1368_data.csv')    # 包含 IUPAC 和 SMILES
df_missing_iupac = pd.read_csv('/home/ubuntu/chem_mol_assistant/Dataset/Inhibitor1368_molecular_properties_new_all.csv')  # 缺失 IUPAC，仅有 SMILES

# 将带有IUPAC字段的数据转为字典用于查找
smiles_to_iupac = dict(zip(df_with_iupac['SMILES'], df_with_iupac['IUPAC']))

# 定义函数：先查已有数据，没有就用 RDKit 生成
def get_iupac(smiles):
    # 优先从已有映射中查找
    if smiles in smiles_to_iupac:
        return smiles_to_iupac[smiles]
    # 否则尝试用 RDKit 生成
    try:
        mol = Chem.MolFromSmiles(smiles)
        if mol is not None:
            return rdMolDescriptors.CalcMolFormula(mol)  # 或者 Chem.rdMolDescriptors.CalcMolFormula
    except:
        return None
    return None

# 应用函数并生成新的 IUPAC 字段
df_missing_iupac['IUPAC'] = df_missing_iupac['SMILES'].progress_apply(get_iupac)

# 保存结果
df_missing_iupac.to_csv('/home/ubuntu/chem_mol_assistant/Dataset/Inhibitor1368_molecular_properties_new_all.csv', index=False)
print("补全完成，已保存到 /home/ubuntu/chem_mol_assistant/Dataset/Inhibitor1368_molecular_properties_new_all.csv")
