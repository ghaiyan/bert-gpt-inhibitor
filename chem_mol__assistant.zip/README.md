# 化学分子生成科研助手

## 使用方法
1. 安装依赖：
```
conda create -n chem_assistant python=3.10
conda activate chem_assistant
pip install -r requirements.txt
```

2. 启动应用：
```
streamlit run app.py
```

3. 分子生成基于 Chemformer，性能预测基于 ChemProp 训练模型。

## 注意事项
- 请放置训练好的 ChemProp 模型至 models/chemprop_model/
- 默认使用 "seyonec/Chemformer" 模型（来自 Huggingface）
