import pandas as pd
import json

# 读取CSV文件
df = pd.read_csv("/home/ubuntu/chem_mol_assistant/Dataset/Inhibitor1368_molecular_properties_new_all.csv")

# 生成英文context段
def build_context(row):
    context = (
        f"The molecule, with IUPAC name {row['IUPAC']} and SMILES {row['SMILES']}, "
        f"has the following molecular properties: "
        f"QED = {row['qed']}, LogP = {row['logp']}, molecular weight = {row['molwt']}, "
        f"HBA = {row['HBA']}, HBD = {row['HBD']}, TPSA = {row['TPSA']}, "
        f"number of rotatable bonds = {row['NumRotBonds']}. "
        f"At a concentration of {row['Concentration_mM']} mM, "
        f"its corrosion inhibition efficiency (IE) is {row['IE']}%. "
        f"Other quantum chemical descriptors include: "
        f"HOMO = {row['HOMO']} eV, LUMO = {row['LUMO']} eV, HOMO-LUMO gap = {row['HOMO-LUMO Gap']} eV, "
        f"dipole moment = {row['dipole_moment']} Debye, ionization potential = {row['Ionization Potential']} eV, "
        f"electron affinity = {row['Electron Affinity']} eV. "
        f"Electronegativity = {row['Electronegativity']}, hardness = {row['Hardness']}, "
        f"softness = {row['Softness']}, electrophilicity = {row['Electrophilicity']}."
    )
    return context

# 生成英文问题
def build_question(row):
    return f"What is the inhibition efficiency (IE) of the molecule with SMILES {row['SMILES']}?"

# 生成英文答案
def build_answer(row):
    return f"The inhibition efficiency of this molecule is {row['IE']}%."

# 构造 JSON 数据
records = []
for _, row in df.iterrows():
    try:
        item = {
            "id": str(row['id']),
            "question": build_question(row),
            "context": build_context(row),
            "answer": build_answer(row)
        }
        records.append(item)
    except Exception as e:
        print(f"Skipping row due to error: {e}")

# 保存为 JSON 文件
output_path = "/home/ubuntu/chem_mol_assistant/Dataset/Inhibitor1368_molecular_properties_new_all_en_deepseek_reasoner_qa.json"
with open(output_path, "w", encoding='utf-8') as f:
    json.dump(records, f, ensure_ascii=False, indent=2)

print(f"✅ 转换完成，已保存为: {output_path}")
