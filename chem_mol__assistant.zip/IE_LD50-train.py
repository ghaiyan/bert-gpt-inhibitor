import pandas as pd
import numpy as np
import joblib
from rdkit import Chem
from rdkit.Chem import MACCSkeys
from sklearn.preprocessing import StandardScaler
import os
import torch
from transformers import AutoTokenizer, AutoModel
import xgboost as xgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from scipy.stats import spearmanr
import time

# ====================== 通用工具函数 ======================
def smiles_to_maccs(smiles):
    """将SMILES转换为MACCS指纹"""
    mol = Chem.MolFromSmiles(smiles)
    if mol:
        maccs = MACCSkeys.GenMACCSKeys(mol)
        return np.array(maccs)
    else:
        return None

def get_chemberta_embeddings(smiles_list, tokenizer, model):
    """使用ChemBERTa获取分子嵌入"""
    input_ids = tokenizer(smiles_list, padding=True, truncation=True, return_tensors="pt")
    with torch.no_grad():
        outputs = model(**input_ids)
        embeddings = outputs.last_hidden_state
    pooled_embeddings = torch.mean(embeddings, dim=1)
    return pooled_embeddings.numpy()

def get_metrics(X_, y_, model, option='Train'):
    """评估模型性能"""
    y_pred = model.predict(X_)
    mse = np.round(mean_squared_error(y_, y_pred), 4)
    rmse = np.round(np.sqrt(mse), 4)
    mae = np.round(mean_absolute_error(y_, y_pred), 4)
    r2 = np.round(r2_score(y_, y_pred), 4)
    spearman_corr, _ = np.round(spearmanr(y_, y_pred), 4)
    
    print(f"\n{option} Metrics:")
    print(f"MSE: {mse}, RMSE: {rmse}, MAE: {mae}")
    print(f"R²: {r2}, Spearman: {spearman_corr}")
    return y_pred

# ====================== IE模型训练部分 ======================
def train_ie_model(data_path="Dataset/Inhibitor1368_molecular_properties_new_all.csv", 
                  model_save_path="ie_xgb_model.json"):
    """训练并保存IE预测模型"""
    print("\n===== Training IE Model =====")
    
    # 加载数据
    df = pd.read_csv(data_path)[["SMILES", "IE", "Concentration_mM"]]
    print(f"Loaded {len(df)} samples")
    
    # 加载ChemBERTa
    model_name = "models/ChemBERTa-77M-MTR"
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModel.from_pretrained(model_name)
    
    # 生成嵌入
    print("Generating ChemBERTa embeddings...")
    embeddings = get_chemberta_embeddings(df["SMILES"].tolist(), tokenizer, model)
    column_names = [f'x{i}' for i in range(embeddings.shape[1])]
    embeddings_df = pd.DataFrame(embeddings, columns=column_names)
    
    # 合并数据
    data = pd.concat([df, embeddings_df], axis=1)
    descriptors = ['Concentration_mM']
    
    # 数据分割
    train_df, temp_df = train_test_split(data, test_size=0.2, random_state=21)
    val_df, test_df = train_test_split(temp_df, test_size=0.5, random_state=21)
    print(f"\nData split: Train={len(train_df)}, Val={len(val_df)}, Test={len(test_df)}")
    
    # 训练XGBoost
    xgb_model = xgb.XGBRegressor(
        objective='reg:squarederror',
        colsample_bytree=0.9,
        learning_rate=0.1,
        max_depth=4,
        n_estimators=200,
        subsample=0.8,
        random_state=42
    )
    
    print("\nTraining XGBoost model...")
    xgb_model.fit(train_df[column_names + descriptors], train_df["IE"])
    
    # 评估
    print("\nModel Evaluation:")
    for name, df in [('Train', train_df), ('Validation', val_df), ('Test', test_df)]:
        get_metrics(df[column_names + descriptors], df["IE"], xgb_model, option=name)
    
    # 保存模型
    xgb_model.save_model(model_save_path)
    print(f"\nModel saved to {model_save_path}")
    
    return xgb_model, tokenizer, model, column_names

train_ie_model(data_path="Dataset/Inhibitor1368_molecular_properties_new_all.csv", model_save_path="ie_xgb_model.json")