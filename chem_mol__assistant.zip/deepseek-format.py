import pandas as pd
import json
from rdkit import Chem
from rdkit.Chem import Descriptors

def convert_to_deepseek_format(input_csv, output_json):
    """
    完整转换函数（包含浓度处理）
    参数:
        input_csv: 输入CSV路径
        output_json: 输出JSON路径
    返回:
        转换后的字典数据
    """
    # 1. 读取数据
    df = pd.read_csv(input_csv)
    
    # 2. 数据清洗
    df = clean_data(df)
    
    # 3. 构建完整数据结构
    reasoner_data = {
        "metadata": {
            "description": "腐蚀抑制剂数据集（含浓度参数）",
            "version": "1.1",
            "fields": build_field_schema(),
            "units": {
                "concentration": "mM",
                "energy": "eV",
                "dipole": "debye",
                "volume": "Å³",
                "surface_area": "Å²"
            }
        },
        "molecules": []
    }

    # 4. 转换每条记录
    for _, row in df.iterrows():
        mol_data = {
            "identifier": build_identifier(row),
            "experimental": build_experimental_data(row),
            "molecular_properties": build_molecular_properties(row),
            "electronic_features": build_electronic_features(row),
            "performance": {
                "corrosion_inhibition": {
                    "efficiency": row.get('IE', None),
                    "test_conditions": {
                        "concentration_mM": row['Concentration_mM'],
                        "normalized_conc_M": row['Concentration_mM'] / 1000
                    }
                }
            },
            "quantum_chemical": build_quantum_chemical(row)
        }
        reasoner_data["molecules"].append(mol_data)
    
    # 5. 保存结果
    with open(output_json, 'w', encoding='utf-8') as f:
        json.dump(reasoner_data, f, indent=2, ensure_ascii=False)
    
    return reasoner_data

def clean_data(df):
    """数据清洗"""
    # 移除无效SMILES
    df = df[df['SMILES'].apply(validate_smiles)]
    
    # 处理缺失值
    df['Concentration_mM'] = df['Concentration_mM'].fillna(df['Concentration_mM'].median())
    
    # 重命名列避免特殊字符问题
    df = df.rename(columns={
        'HOMO-LUMO Gap': 'HOMO_LUMO_Gap'
    })
    
    return df

def validate_smiles(smiles):
    """验证SMILES有效性"""
    try:
        return Chem.MolFromSmiles(smiles) is not None
    except:
        return False

def build_field_schema():
    """构建完整的字段模式"""
    return [
        {
            "name": "experimental",
            "type": "group",
            "fields": [
                {"name": "concentration_mM", "type": "float", "description": "测试浓度(mM)"},
                {"name": "temperature_C", "type": "float", "description": "测试温度(℃)", "optional": True}
            ]
        },
        {
            "name": "quantum_chemical",
            "type": "group",
            "fields": [
                {"name": "homo", "type": "float", "unit": "eV"},
                {"name": "lumo", "type": "float", "unit": "eV"},
                {"name": "dipole", "type": "float", "unit": "debye"}
            ]
        }
    ]

def build_identifier(row):
    """构建分子标识信息"""
    return {
        "smiles": row['SMILES'],
        "inchi": Chem.MolToInchi(Chem.MolFromSmiles(row['SMILES'])) if pd.notnull(row['SMILES']) else None,
        "formula": Chem.rdMolDescriptors.CalcMolFormula(Chem.MolFromSmiles(row['SMILES'])) if pd.notnull(row['SMILES']) else None
    }

def build_experimental_data(row):
    """构建实验条件数据"""
    return {
        "concentration": {
            "value": row['Concentration_mM'],
            "unit": "mM",
            "normalized": row['Concentration_mM'] / 1000,
            "classification": classify_concentration(row['Concentration_mM'])
        }
    }

def classify_concentration(conc):
    """浓度级别分类"""
    if conc < 1: return "low"
    elif 1 <= conc <= 10: return "medium"
    else: return "high"

def build_molecular_properties(row):
    """构建分子性质数据"""
    mol = Chem.MolFromSmiles(row['SMILES'])
    return {
        "physical": {
            "molecular_weight": row['molwt'],
            "logp": row['logp'],
            "tpsa": row['TPSA']
        },
        "structural": {
            "h_bond_acceptors": row['HBA'],
            "h_bond_donors": row['HBD'],
            "rotatable_bonds": row['NumRotBonds'],
            "element_counts": {
                "N": row['N_count'],
                "O": row['O_count'],
                "S": row['S_count'],
                "P": row['P_count']
            }
        }
    }

def build_electronic_features(row):
    """构建电子特征"""
    return {
        "frontier_orbitals": {
            "homo": row['HOMO'],
            "lumo": row['LUMO'],
            "gap": row['HOMO_LUMO_Gap']
        },
        "reactivity": {
            "electronegativity": row['Electronegativity'],
            "hardness": row['Hardness']
        }
    }

def build_quantum_chemical(row):
    """构建量子化学参数"""
    return {
        "electronic_parameters": {
            "ionization_potential": row['Ionization Potential'],
            "electron_affinity": row['Electron Affinity']
        },
        "global_descriptors": {
            "electrophilicity": row['Electrophilicity'],
            "donor_capacity": row['Electron Donor Capacity'],
            "acceptor_capacity": row['Electron Acceptor Capacity']
        },
        "steric_properties": {
            "vdw_volume": row['vdw_volume'],
            "vdw_surface_area": row['vdw_surface_area']
        }
    }

# 使用示例
if __name__ == "__main__":
    # 转换数据
    data = convert_to_deepseek_format(
        input_csv="/home/ubuntu/chem_mol_assistant/Dataset/Inhibitor1368_molecular_properties_new_all.csv",
        output_json="/home/ubuntu/chem_mol_assistant/Dataset/Inhibitor1368_molecular_deepseek_reasoner_format.json"
    )
    
    # 打印摘要信息
    print(f"转换完成！共处理 {len(data['molecules'])} 个分子")
    print(f"浓度范围: {min(m['experimental']['concentration']['value'] for m in data['molecules'])}-"
          f"{max(m['experimental']['concentration']['value'] for m in data['molecules'])} mM")