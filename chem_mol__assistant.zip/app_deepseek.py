import streamlit as st
import pandas as pd
import os
from agents.recommender_agent import HybridRecommenderAgent
from agents import generator_agent, predictor_agent, recommender_agent, literature_agent
from agents.literature_agent import LiteratureAgent
from deepseek_intent_router import DeepSeekIntentRouter
import json

# === 用户数据文件路径 ===
USER_CSV_PATH = "users.csv"
st.set_page_config(page_title="Corrosion Inhibitor Molecular Research Assistant", layout="wide")
USER_DATA_DIR = "user_data"
os.makedirs(USER_DATA_DIR, exist_ok=True)

def load_user_data(username):
    filepath = f"{USER_DATA_DIR}/{username}.json"
    if os.path.exists(filepath):
        with open(filepath, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"chat_history": []}

def save_user_data(username, data):
    os.makedirs(USER_DATA_DIR, exist_ok=True)
    filepath = f"{USER_DATA_DIR}/{username}.json"
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

if not os.path.exists(USER_CSV_PATH):
    pd.DataFrame(columns=["username", "password"]).to_csv(USER_CSV_PATH, index=False)

def rerun():
    st.session_state['_rerun'] = not st.session_state.get('_rerun', False)
    st.stop()

def load_users():
    df = pd.read_csv(USER_CSV_PATH, dtype={"username": str, "password": str})
    df["username"] = df["username"].str.strip()
    df["password"] = df["password"].str.strip()
    return df

def save_user(username, password):
    username = username.strip()
    password = password.strip()
    df = load_users()
    if username in df["username"].values:
        return False
    df.loc[len(df)] = [username, password]
    df.to_csv(USER_CSV_PATH, index=False)
    return True
def show_login():
    st.sidebar.title("🔐 登录系统 / Login System")
    page = st.sidebar.radio("选择操作 / Select Action", ["登录 / Login", "注册 / Register"])

    if page == "登录 / Login":
        username = st.sidebar.text_input("用户名 / Username")
        password = st.sidebar.text_input("密码 / Password", type="password")

        if st.sidebar.button("登录 / Login"):
            username = username.strip()
            password = password.strip()
            users = load_users()
            users_match = users[
                (users["username"] == username) & (users["password"] == password)
            ]
            if not users_match.empty:
                st.session_state.user_logged_in = True
                st.session_state.username = username
                user_data = load_user_data(username)
                st.session_state[f"{username}_chat_history"] = user_data.get("chat_history", [])
                st.session_state[f"{username}_display_df"] = None
                st.session_state[f"{username}_recommendations"] = None
                st.session_state.page_reload = st.session_state.get("page_reload", 0) + 1
            else:
                st.sidebar.error("用户名或密码错误 / Incorrect username or password")

    elif page == "注册 / Register":
        new_username = st.sidebar.text_input("新用户名 / New Username")
        new_password = st.sidebar.text_input("设置密码 / Set Password", type="password")
        confirm_password = st.sidebar.text_input("确认密码 / Confirm Password", type="password")

        if st.sidebar.button("注册 / Register"):
            if new_password != confirm_password:
                st.sidebar.error("两次密码不一致 / Passwords do not match")
            elif len(new_username.strip()) == 0:
                st.sidebar.error("用户名不能为空 / Username cannot be empty")
            else:
                success = save_user(new_username, new_password)
                if success:
                    save_user_data(new_username, {"chat_history": []})
                    st.sidebar.success("注册成功！请切换到登录并登录。 / Registration successful! Please switch to login.")
                else:
                    st.sidebar.warning("用户名已存在，请更换其他用户名。 / Username already exists, please choose another one.")
def main_app(username):
    st.sidebar.success(f"Welcome，{username}！")
    if st.sidebar.button("login out"):
        save_user_data(username, {
            "chat_history": st.session_state[f"{username}_chat_history"]
        })
        st.session_state.user_logged_in = False
        rerun()

    chat_history_key = f"{username}_chat_history"
    display_df_key = f"{username}_display_df"
    recommendations_key = f"{username}_recommendations"

    if chat_history_key not in st.session_state:
        st.session_state[chat_history_key] = []
    if display_df_key not in st.session_state:
        st.session_state[display_df_key] = None
    if recommendations_key not in st.session_state:
        st.session_state[recommendations_key] = None

    agent = HybridRecommenderAgent(
        csv_path="Dataset/Inhibitor1368_molecular_properties_new_all.csv",
        qa_json_path="Dataset/Inhibitor1368_molecular_properties_new_all_en_deepseek_reasoner_qa.json"
    )
    intent_router = DeepSeekIntentRouter(
        generator_agent=generator_agent,
        predictor_agent=predictor_agent,
        recommender_agent=agent
    )
    literature_agent_inst = LiteratureAgent()

    st.title("🧪 Corrosion Inhibitor Molecule Generation Assistant")

    # Add Agent功能说明/Instructions section
    with st.expander("📌 Agent功能说明 / Instructions", expanded=True):
        st.markdown("""
        **本系统针对室温25℃下碳钢材料的缓蚀剂分子提供生成与预测推荐等功能 / This system provides generation and prediction recommendations for corrosion inhibitor molecules for carbon steel materials at room temperature (25°C):**

        1. **分子生成 (Molecule Generation)**
           - 根据描述性要求生成腐蚀抑制剂分子 / Generate corrosion inhibitor molecules based on descriptive requirements
           - 示例 / Example: 
             - 中文: "生成10个IE>0.9且LD50>1500的咪唑类腐蚀抑制剂"
             - English: "Generate 10 imidazole corrosion inhibitors with IE>0.9 and LD50>1500"
           - 输出 / Output: 生成分子及其预测性质 / Generated molecules and their predicted properties

        2. **性质预测 (Property Prediction)**
           - 预测给定SMILES分子的抑制效率(IE)和毒性(LD50) / Predict inhibition efficiency (IE) and toxicity (LD50) for given SMILES molecules
           - 示例 / Example:
             - 中文: "预测SMILES CCC(=O)O在0.1mM下的IE和LD50"
             - English: "Predict IE and LD50 for SMILES CCC(=O)O on 0.1 mM concentration"
           - 输出 / Output: 预测结果及在不同浓度下的表现 / Prediction results and performance at different concentrations

        3. **分子推荐 (Molecule Recommendation)**
           - 基于不同相似度方法推荐类似分子 / Recommend similar molecules based on different similarity methods:
             - 结构相似性 (Structure similarity)
             - 分子指纹相似性 (Fingerprint similarity)
             - 性质相似性 (Property similarity)
             - 语义相似性 (Semantic similarity based on deepseek reasoner)
           - 示例 / Example:
             - 中文: "推荐与SMILES C1=CC=CN=C1相似的分子"
             - English: "Recommend molecules similar to SMILES C1=CC=CN=C1"

        4. **文献专利查询 (Literature & Patent Search)**
           - 查询分子相关的科学文献和专利信息 / Search for scientific literature and patent information related to molecules
           - 自动从PubChem获取相关资料 / Automatically retrieve relevant data from PubChem

        **使用提示 / Usage Tips:**
        - 您可以直接用自然语言描述您的需求 / You can directly describe your needs in natural language
        - 系统会自动识别任务类型并执行相应操作 / The system will automatically identify the task type and perform corresponding operations
        - 对话历史会被保存，方便您后续查看 / Conversation history will be saved for your future reference
        """)

    with st.expander("💬 Conversation History", expanded=True):
        if not st.session_state[chat_history_key]:
            st.info("No conversation yet.")
        else:
            for turn in st.session_state[chat_history_key]:
                st.markdown(f"**🧑 User:** {turn['user']}")
                st.markdown(f"**🤖 Assistant:** {turn['assistant']}")
                st.markdown("---")

    user_input = st.text_input("💡 Describe your task or ask a question (e.g., generate 100 imidazole corrosion inhibitor with IE>0.9 and LD50>1500, predict SMILES xxx, recommend SMILES xxx)")

    if st.button("🚀 Execute Task"):
        if not user_input.strip():
            st.warning("Please input a valid task description.")
        else:
            with st.spinner("Parsing and executing task..."):
                result = intent_router.route_and_execute(user_input)
                task = result.get("task")
                assistant_reply = ""

                if result.get("error"):
                    assistant_reply = f"❌ Error: {result['error']}"
                    st.error(assistant_reply)
                    if "detail" in result:
                        st.text(result["detail"])

                elif task == "generate":
                    st.success("✅ Molecule generation completed!")
                    csv_path = result["csv_path"]
                    st.session_state["csv_path"] = csv_path
                    df_mols = pd.read_csv(csv_path)
                    smiles_list = df_mols['smiles'].dropna().tolist()
                    if not smiles_list:
                        assistant_reply = "No valid SMILES found in generated molecules."
                        st.error(assistant_reply)
                    else:
                        with st.spinner("Predicting properties..."):
                            concentration_gen = 1
                            results_df = predictor_agent.predict_properties(smiles_list, concentration_mM=concentration_gen)
                        df_mols.rename(columns=lambda x: x.lower(), inplace=True)
                        results_df.rename(columns=lambda x: x.lower(), inplace=True)
                        if 'sas' in df_mols.columns:
                            merged_df = pd.merge(results_df, df_mols[['smiles', 'sas']], on='smiles', how='left')
                        else:
                            merged_df = results_df.copy()
                            merged_df['sas'] = None
                        merged_df['concentration_mM'] = concentration_gen
                        top10_df = merged_df.sort_values(by='predicted_ie', ascending=False).head(10)
                        display_df = top10_df[['smiles', 'concentration_mM', 'predicted_ie', 'predicted_ld50', 'sas']]
                        display_df.columns = ['SMILES', 'concentration(mM)', 'predicted_ie', 'predicted_ld50', 'Synthesizability (SAS)']
                        st.session_state[display_df_key] = display_df
                        top1_smiles = display_df.iloc[0]['SMILES']
                        recs = agent.recommend(query_smiles=top1_smiles, mode="fingerprint", top_k=5)
                        st.session_state[recommendations_key] = recs
                        assistant_reply = f"Generated {len(display_df)} molecules. Top SMILES: {top1_smiles}"

                elif task == "predict":
                    concentration_pred = result.get("concentration_mM", 1.0)
                    st.success(f"✅ Property prediction completed at {concentration_pred} mM concentration!")
                    df = pd.DataFrame(result["results"])
                    df.columns = [col.lower() for col in df.columns]
                    if 'concentration_mm' not in df.columns:
                        df['concentration_mm'] = concentration_pred
                    st.session_state[display_df_key] = df
                    if not df.empty and "smiles" in df.columns:
                        st.write(f"#### Prediction Summary (Concentration: {concentration_pred} mM)")
                        st.write(f"- Total molecules predicted: {len(df)}")
                        if 'predicted_ie' in df.columns:
                            top_molecule = df.loc[df['predicted_ie'].idxmax()]
                            top1_smiles = top_molecule['smiles']
                            top_ie = top_molecule['predicted_ie']
                            st.write(f"- Best inhibitor efficiency: {top_ie:.2%} (SMILES: `{top1_smiles}`)")
                            with st.spinner("Getting recommendations for top molecule..."):
                                try:
                                    recs = agent.recommend(query_smiles=top1_smiles, mode="fingerprint", top_k=5)
                                    st.session_state[recommendations_key] = recs
                                    assistant_reply = (f"Predicted properties for {len(df)} molecules at {concentration_pred} mM. "
                                                    f"Top molecule: {top1_smiles} (IE: {top_ie:.2%})")
                                except Exception as e:
                                    st.warning(f"Recommendation failed: {str(e)}")
                                    assistant_reply = (f"Predicted properties for {len(df)} molecules at {concentration_pred} mM. "
                                                    f"Top molecule: {top1_smiles} (IE: {top_ie:.2%})")
                        else:
                            top1_smiles = df.iloc[0]['smiles']
                            assistant_reply = f"Predicted properties for {len(df)} molecules at {concentration_pred} mM. First SMILES: {top1_smiles}"
                    else:
                        assistant_reply = "No valid prediction results returned."
                        st.error(assistant_reply)

                elif task == "recommend":
                    st.success("✅ Recommendation completed!")
                    st.session_state[recommendations_key] = result.get("recommendations")
                    st.session_state[display_df_key] = None
                    assistant_reply = f"Found {len(st.session_state[recommendations_key])} recommendations."

                st.session_state[chat_history_key].append({"user": user_input, "assistant": assistant_reply})
                save_user_data(username, {
                    "chat_history": st.session_state[chat_history_key]
                })

    if st.session_state[display_df_key] is not None:
        st.write("### 📊 Predicted Molecules and Properties")
        st.dataframe(st.session_state[display_df_key])
        csv_bytes = st.session_state[display_df_key].to_csv(index=False).encode('utf-8')
        st.download_button("📥 Download Prediction CSV", csv_bytes, "predicted_molecules.csv", "text/csv")

    if st.session_state[display_df_key] is not None:
        st.write("### 🔍 Interactive Recommendation")
        smiles_col = [c for c in st.session_state[display_df_key].columns if c.lower() == "smiles"]
        if smiles_col:
            smiles_options = st.session_state[display_df_key][smiles_col[0]].tolist()
            selected_smiles = st.selectbox("Select SMILES for recommendation", options=smiles_options)

            if selected_smiles:
                st.write(f"Selected SMILES: `{selected_smiles}`")
                recommend_mode = st.radio("Choose recommendation mode", ["structure", "fingerprint", "property", "semantic based on deepseek reasoner"])

                if st.button("Get Recommendations"):
                    with st.spinner("Getting recommendations..."):
                        try:
                            if recommend_mode == "semantic based on deepseek reasoner":
                                # 语义推荐调用（新增部分）
                                semantic_query = f"What corrosion inhibitors are similar or related to the molecule with SMILES {selected_smiles}?"
                                rec_results = agent.recommend(semantic_query=semantic_query, mode="semantic based on deepseek reasoner", top_k=5)
                                st.session_state[recommendations_key] = rec_results
                            else:
                                rec_results = agent.recommend(query_smiles=selected_smiles, mode=recommend_mode, top_k=5)
                                st.session_state[recommendations_key] = rec_results

                            st.session_state[chat_history_key].append({
                                "user": f"Recommend based on {selected_smiles} ({recommend_mode})",
                                "assistant": f"Returned {len(st.session_state[recommendations_key])} recommended molecules."
                            })
                            save_user_data(username, {
                                "chat_history": st.session_state[chat_history_key]
                            })
                        except Exception as e:
                            st.error(f"Recommendation failed: {e}")

    if st.session_state[recommendations_key] is not None:
        st.write("### 🧬 Recommendation Results")
        recs = st.session_state[recommendations_key]

        if isinstance(recs, list) and recs:
            rec_df = pd.DataFrame(recs)
            if 'answer' in rec_df.columns:
                # 语义推荐结果特殊展示（新增部分）
                for item in recs:
                    st.markdown(f"**SMILES:** {item.get('smiles', 'N/A')}")
                    st.markdown(f"**Predicted IE:** {item.get('IE', 'N/A')}")
                    st.markdown(f"**Predicted LD50:** {item.get('LD50', 'N/A')}")
                    st.markdown(f"**Answer:** {item.get('answer', '')}")
                    if item.get("context"):
                        st.markdown(f"*Context:* {item.get('context')}")
                    st.markdown("---")
            else:
                cols = [c for c in ["id", "smiles", "iupac", "IE", "concentration_mM", "similarity_score"] if c in rec_df.columns]
                st.dataframe(rec_df[cols])
                st.download_button(
                    "📥 Download Recommended Molecules CSV",
                    rec_df.to_csv(index=False).encode("utf-8"),
                    "recommended_molecules.csv",
                    "text/csv"
                )

            # 文献和专利查询（保留原功能）
            st.write("### 📚 Literature and Patent Query for Selected Molecule")
            selected_for_lit = st.selectbox("Select a molecule SMILES to query related literature and patents:", options=rec_df['smiles'].tolist())

            if st.button("Query Literature and Patents"):
                with st.spinner("Querying PubChem literature and patents..."):
                    try:
                        cid = literature_agent_inst.get_cid_from_smiles(selected_for_lit)
                        if cid is None:
                            st.warning("Cannot find PubChem CID for selected molecule.")
                        else:
                            cid_str = str(cid)
                            lit_df = literature_agent_inst.get_literature(cid_str, limit=5)
                            patent_df = literature_agent_inst.get_patents(cid_str, limit=5)

                            if not lit_df.empty:
                                st.write("#### Related Literature")
                                st.dataframe(lit_df)
                            else:
                                st.info("No related literature found.")

                            if not patent_df.empty:
                                st.write("#### Related Patents")
                                st.dataframe(patent_df)
                            else:
                                st.info("No related patents found.")

                            # 缓存结果，避免重复查询
                            st.session_state['last_literature'] = lit_df
                            st.session_state['last_patents'] = patent_df

                    except Exception as e:
                        st.error(f"Query failed: {e}")

            # 如果需要，可以在其他地方展示缓存的结果
            if 'last_literature' in st.session_state and not st.session_state['last_literature'].empty:
                st.write("### Cached Literature Results")
                st.dataframe(st.session_state['last_literature'])


if __name__ == "__main__":
    if "user_logged_in" not in st.session_state:
        st.session_state.user_logged_in = False
    if "page_reload" not in st.session_state:
        st.session_state.page_reload = 0

    if not st.session_state.user_logged_in:
        show_login()
        st.stop()
    else:
        username = st.session_state.username
        main_app(username)
