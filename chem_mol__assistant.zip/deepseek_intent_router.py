# deepseek_intent_router.py
import os
import json
import re
from openai import OpenAI
from dotenv import load_dotenv
from rdkit import Chem

# 加载环境变量
load_dotenv()

class DeepSeekIntentRouter:
    def __init__(self, generator_agent, predictor_agent, recommender_agent, synthesis_agent=None, literature_agent=None):
        self.client = OpenAI(
            api_key=os.getenv("DEEPSEEK_API"),
            base_url="https://api.deepseek.com/v1"
        )
        self.generator_agent = generator_agent
        self.predictor_agent = predictor_agent
        self.recommender_agent = recommender_agent
        self.synthesis_agent = synthesis_agent
        self.literature_agent = literature_agent

    def _extract_valid_smiles(self, smiles_text):

        # 类型检查与标准化处理
        if isinstance(smiles_text, list):
            # 如果是列表，拼成一个字符串
            smiles_text = " ".join(smiles_text)
        elif not isinstance(smiles_text, str):
            # 如果不是字符串或列表，直接返回空列表
            return []

        # 替换逗号、分号等常见分隔符，防止分割失败
        smiles_text = smiles_text.replace(',', ' ').replace(';', ' ').replace('\n', ' ')
        fragments = smiles_text.split()  # 使用空格或多个空格分割
        valid_smiles = []

        for frag in fragments:
            try:
                mol = Chem.MolFromSmiles(frag)
                if mol:
                    valid_smiles.append(Chem.MolToSmiles(mol))  # 标准化输出
            except:
                continue

        return valid_smiles

    
    def parse_intent(self, user_prompt: str) -> dict:
        """
        解析用户意图，返回包含任务类型、SMILES和浓度的字典
        返回结构示例: {"task": "predict", "smiles_list": ["CCO"], "concentration_mM": 2.5}
        """
        prompt_lower = user_prompt.lower()
        
        # === 1. 增强的浓度提取 ===
        concentration = self._extract_concentration(prompt_lower)
        
        # === 2. 任务类型判断 ===
        # Generate任务
        if "generate" in prompt_lower and "inhibitor" in prompt_lower:
            return self._parse_generate_intent(prompt_lower)
        
        # Predict任务
        valid_smiles = self._extract_valid_smiles(user_prompt)
        if valid_smiles:
            return {
                "task": "predict",
                "smiles_list": valid_smiles,
                "concentration_mM": concentration
            }
        
        # Recommend任务
        if "recommend" in prompt_lower or "similar" in prompt_lower:
            return self._parse_recommend_intent(user_prompt)
        
        # === 3. 调用大模型解析 ===
        return self._parse_with_llm(user_prompt, concentration)

    def _extract_concentration(self, text: str) -> float:
        """分两阶段解析浓度：正则 → DeepSeek API"""
        # 第一阶段：正则匹配
        conc_patterns = [
            (r'at\s+(\d+\.?\d*)\s*mM\s+conc', 1),
            (r'(\d+\.?\d*)\s*mM', 1),
            # 其他正则模式...
        ]
        
        for pattern, group_idx in conc_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                try:
                    return float(match.group(group_idx))
                except (ValueError, IndexError):
                    continue

        # 第二阶段：正则失败时调用DeepSeek API
        return self._ask_deepseek_for_concentration(text)

    def _ask_deepseek_for_concentration(self, text: str) -> float:
        """调用DeepSeek API解析浓度"""
        system_prompt = """你是一个化学助手，需要从用户输入中提取浓度值（单位mM）。
        只需返回一个JSON，格式如：{"concentration_mM": 数值}。
        若未指定浓度，返回1.0。"""
        
        try:
            response = self.client.chat.completions.create(
                model="deepseek-chat",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": text}
                ],
                response_format={"type": "json_object"},
                temperature=0.0  # 减少随机性
            )
            result = json.loads(response.choices[0].message.content)
            return float(result.get("concentration_mM", 1.0))
        except Exception as e:
            print(f"DeepSeek API调用失败: {str(e)}")
            return 1.0  # 保底默认值



    def _parse_recommend_intent(self, text: str) -> dict:
        """改进的推荐任务解析，支持复杂SMILES"""
        # 尝试直接提取SMILES部分（包含所有可能字符）
        smiles_match = re.search(
            r'(?:^|\s)((?:[A-Za-z0-9@+\-\[\]\(\)=#$\\/\.]|%[0-9]{2})+)(?:\s|$)', 
            text
        )
        
        # 如果没有显式匹配，尝试提取看起来最像SMILES的部分
        if not smiles_match:
            potential_smiles = re.findall(
                r'(?:^|\s)((?:[A-Za-z0-9@+\-\[\]\(\)=#$\\/\.]|%[0-9]{2}){6,})(?:\s|$)',
                text
            )
            candidate = potential_smiles[0] if potential_smiles else None
        else:
            candidate = smiles_match.group(1)
        
        # 验证SMILES有效性
        smiles = None
        if candidate:
            valid_smiles_list = self._extract_valid_smiles(candidate)
            if valid_smiles_list:
                smiles = valid_smiles_list[0]  # 取第一个有效的
                print(f"DEBUG - Extracted SMILES: {smiles}")  # 调试输出

        return {
            "task": "recommend",
            "smiles": smiles,
            "mode": "fingerprint",
            "top_k": 5
        }


    def _parse_generate_intent(self, prompt_lower: str) -> dict:
        """解析生成任务意图"""
        num_match = re.search(r'generate\s+(\d+)', prompt_lower)
        scaffold_match = re.search(r'generate.*?(\w+)?\s*inhibitor', prompt_lower)
        
        constraints = {}
        for key in ["ie", "ld50"]:
            match = re.search(fr'{key}\s*([><=]+)\s*([\d\.]+)', prompt_lower)
            if match:
                constraints[key.upper()] = f"{match.group(1)}{match.group(2)}"
        
        return {
            "task": "generate",
            "molecule_type": scaffold_match.group(1) if scaffold_match else "",
            "constraints": constraints,
            "num": int(num_match.group(1)) if num_match else 50
        }


    def _parse_with_llm(self, user_prompt: str, default_conc: float) -> dict:
        """使用大模型解析意图"""
        system_prompt = """你是一个化学研究助手，请严格按以下要求分析请求：
1. 对于预测任务，必须包含：
   - task: "predict"
   - smiles_list: [有效的SMILES数组]
   - concentration_mM: 数值(必须，默认1.0)
2. 返回规范的JSON格式，包含所有必填字段

示例：
{
  "task": "predict",
  "smiles_list": ["CCO", "CCN"],
  "concentration_mM": 2.5,
  "comment": "预测乙醇和乙胺在2.5mM下的性质"
}"""
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        try:
            response = self.client.chat.completions.create(
                model="deepseek-chat",
                messages=messages,
                response_format={"type": "json_object"},
                temperature=0.3  # 降低随机性
            )
            intent = json.loads(response.choices[0].message.content)
            
            # 后处理验证
            if intent.get("task") == "predict":
                if not intent.get("smiles_list"):
                    return {"error": "请提供有效的SMILES结构"}
                if "concentration_mM" not in intent:
                    intent["concentration_mM"] = default_conc
            
            return intent
        except Exception as e:
            return {"error": f"解析失败: {str(e)}"}

    def route_and_execute(self, user_prompt: str) -> dict:
        """根据任务意图，调用对应 Agent 完成任务"""
        intent = self.parse_intent(user_prompt)

        if "error" in intent:
            return intent

        if "task" not in intent:
            return {"error": "Failed to detect task", "detail": intent.get("raw_response", "")}

        task = intent.get("task").lower()

        try:
            if task == "generate":
                scaffold = intent.get("molecule_type", "")
                constraints = intent.get("constraints", {})
                num = intent.get("num", 50)
                prompt_parts = []
                if scaffold:
                    prompt_parts.append(scaffold)
                for k, v in constraints.items():
                    prompt_parts.append(f"{k}{v}")
                prompt_str = f"generate {num} {' '.join(prompt_parts)} corrosion inhibitor"
                csv_path = self.generator_agent.generate_and_save(prompt_str)
                return {"task": "generate", "csv_path": csv_path}

            elif task == "predict":
                smiles_list = intent.get("smiles_list", [])
                concentration = intent.get("concentration_mM", 1.0)  # 默认1.0 mM
                
                if not smiles_list:
                    return {"error": "No SMILES provided for prediction. Please provide valid SMILES."}
                
                # 验证SMILES有效性
                valid_smiles = []
                for s in smiles_list:
                    try:
                        if Chem.MolFromSmiles(s):
                            valid_smiles.append(s)
                    except:
                        continue
                
                if not valid_smiles:
                    return {"error": "No valid SMILES found. Please provide correct SMILES for prediction."}
                
                results_df = self.predictor_agent.predict_properties(
                    valid_smiles, 
                    concentration_mM=concentration
                )
                return {
                    "task": "predict", 
                    "results": results_df.to_dict(orient="records"),
                    "concentration_mM": concentration
                }

            elif task == "recommend":
                smiles = intent.get("smiles")
                mode = intent.get("mode", "fingerprint")
                top_k = intent.get("top_k", 5)
                if not smiles:
                    return {"error": "No SMILES provided for recommendation"}
                recs = self.recommender_agent.recommend(query_smiles=smiles, mode=mode, top_k=top_k)
                return {"task": "recommend", "recommendations": recs}

            else:
                return {"error": f"Unknown task type: {task}"}

        except Exception as e:
            return {"error": "Execution failed", "detail": str(e)}