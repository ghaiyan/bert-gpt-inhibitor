import streamlit as st
import pandas as pd
import os
from agents.recommender_agent import HybridRecommenderAgent
from agents import generator_agent, predictor_agent

st.set_page_config(page_title="Chemical Molecular Research Assistant", layout="wide")
st.title("Molecule Generation Assistant - Generate potential corrosion inhibitors based on prompt words")

# ===== 初始化 session_state =====
if "csv_path" not in st.session_state:
    st.session_state.csv_path = None
if "display_df" not in st.session_state:
    st.session_state.display_df = None

# ===== 显示全流程阶段标题（保持不消失） =====
st.subheader("📌 Step 1: Molecule Generation")
st.subheader("📈 Step 2: Predict corrosion inhibition efficiency and LD50")
st.subheader("🔎 Step 3: Similarity-based Recommendations")

# ===== 初始化推荐器 =====
agent = HybridRecommenderAgent(
    csv_path="Dataset/Inhibitor1368_molecular_properties_new_all.csv",
    qa_json_path="Dataset/Inhibitor1368_molecular_properties_new_all_en_deepseek_reasoner_qa.json"
)

# ===== Step 1: 用户输入提示词 =====
prompt = st.text_input("Enter prompt (e.g.: generate 100 imidazole corrosion inhibitor with IE>0.9 and LD50>1500)")

if st.button("Generate molecules"):
    if prompt.strip() == "":
        st.warning("Please enter a valid prompt!")
    else:
        with st.spinner("Generating molecules..."):
            csv_path = generator_agent.generate_and_save(prompt)
            st.session_state.csv_path = csv_path

        st.success("✅ Molecule generation completed!")

        df_mols = pd.read_csv(csv_path)
        smiles_list = df_mols['smiles'].dropna().tolist()

        if len(smiles_list) == 0:
            st.error("There are no valid SMILES in the generated molecule file.")
        else:
            with st.spinner("Predicting corrosion inhibition efficiency and LD50..."):
                results_df = predictor_agent.predict_properties(smiles_list)

            if 'sas' in df_mols.columns:
                df_mols.rename(columns=lambda x: x.lower(), inplace=True)
                results_df.rename(columns=lambda x: x.lower(), inplace=True)
                merged_df = pd.merge(results_df, df_mols[['smiles', 'sas']], on='smiles', how='left')
            else:
                merged_df = results_df.copy()
                merged_df['sas'] = None

            merged_df['concentration_mM'] = 1.0
            top10_df = merged_df.sort_values(by='predicted_ie', ascending=False).head(10)
            display_df = top10_df[['smiles', 'concentration_mM', 'predicted_ie', 'predicted_ld50', 'sas']]
            display_df.columns = ['SMILES', 'concentration(mM)', 'predicted_ie', 'predicted_ld50', 'Synthesizability (SAS)']
            st.session_state.display_df = display_df

# ===== Step 2: 展示 Top 10 分子和下载按钮 =====
if st.session_state.display_df is not None:
    st.write("IE top 10 corrosion inhibitor molecules:")
    st.dataframe(st.session_state.display_df)

    csv_bytes = st.session_state.display_df.to_csv(index=False).encode('utf-8')
    st.download_button(
        label="📥 Download CSV file of top 10 IE molecules",
        data=csv_bytes,
        file_name=f"{os.path.basename(st.session_state.csv_path).replace('.csv', '')}_top10_predicted_inhibitors.csv",
        mime="text/csv"
    )

# ===== Step 2.5: 下载完整生成分子文件 =====
if st.session_state.csv_path and os.path.exists(st.session_state.csv_path):
    with open(st.session_state.csv_path, "rb") as f:
        csv_bytes = f.read()
    st.download_button(
        label="📥 Download the generated molecule CSV file",
        data=csv_bytes,
        file_name=os.path.basename(st.session_state.csv_path),
        mime="text/csv"
    )
else:
    st.warning("⚠️ The original file is missing or expired. Please re-generate molecules.")

# ===== Step 3: 相似推荐功能 =====
if st.session_state.display_df is not None:
    smiles_options = st.session_state.display_df['SMILES'].tolist()
    selected_smiles = st.selectbox("Select SMILES for recommendation", options=smiles_options)

    if selected_smiles:
        st.write(f"Selected SMILES: `{selected_smiles}`")

        recommend_mode = st.radio(
            "Choose recommendation mode",
            options=["structure", "fingerprint", "property", "semantic based on deepseek reasoner"]
        )

        if st.button("Get Recommendations"):
            with st.spinner("Getting recommendations..."):
                try:
                    if recommend_mode == "semantic based on deepseek reasoner":
                        semantic_query = f"What corrosion inhibitors are similar or related to the molecule with SMILES {selected_smiles}?"
                        rec_results = agent.recommend(semantic_query=semantic_query, mode="semantic based on deepseek reasoner", top_k=5)
                    else:
                        rec_results = agent.recommend(query_smiles=selected_smiles, mode=recommend_mode, top_k=5)
                except Exception as e:
                    st.error(f"Recommendation failed: {e}")
                    rec_results = []

            if rec_results:
                st.subheader("🧪 Recommendation Results")
                if recommend_mode == "semantic based on deepseek reasoner":
                    for item in rec_results:
                        st.markdown(f"**Answer:** {item['answer']}")
                        if item.get("context"):
                            st.markdown(f"*Context:* {item['context']}")
                        st.markdown("---")
                else:
                    rec_df = pd.DataFrame(rec_results)
                    st.dataframe(rec_df[["id", "smiles", "iupac", "IE", "concentration_mM", "similarity_score"]])

                    st.download_button(
                        label="📥 Download recommended molecules",
                        data=rec_df.to_csv(index=False).encode("utf-8"),
                        file_name=f"recommended_molecules_{recommend_mode}.csv",
                        mime="text/csv"
                    )